package fr.but3.ctp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CtpApplicationTests {

	@Test
	void contextLoads() {
	}

}
