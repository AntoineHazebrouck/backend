package fr.but3.ctp.repositories;

import org.springframework.data.repository.CrudRepository;
import fr.but3.ctp.entities.Choix;

public interface ChoixRepository extends CrudRepository<Choix, Integer>
{

}
