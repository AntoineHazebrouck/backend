package fr.but3.ctp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CtpApplication {

	public static void main(String[] args) {
		SpringApplication.run(CtpApplication.class, args);
	}

}
