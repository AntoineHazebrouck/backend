insert into question(libquest) values ('Date de la bataille de Marignan ?'), ('Quel est le président de la république actuel ?'), ('Qui a découvert la péniciline ?');

insert into choix(qno,libchoix,statut) values (1,'1313',false),(1,'1414',false),(1,'1515',true),(1,'1616',false);
insert into choix(qno,libchoix,statut) values (2,'Chirac',false),(2,'Sarkozy',false),(2,'Hollande',false),(2,'Macron',true);
insert into choix(qno,libchoix,statut) values (3,'Darwin',false),(3,'Pasteur',false),(3,'Fleming',true),(3,'Watson',false);
       