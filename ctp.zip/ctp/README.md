## Antoine HAZEBROUCK, BUT3

BDD = h2 in memory

Création automatique des tables : oui


Q1 fait
Q2 fait
Q3 fait
Q8 fait (il manque le default à zero pour nbchoix)
Q4 fait (il faut gerer le null lié au manque du default à zero pour nbchoix)
